# portfolio
New design for my portfolio

I'm re-designing my portfolio. aim is to de-clutter UI and require less effort for user to navigate.

Figma files for new design - https://www.figma.com/file/jNFfYOHPylpqJzKP8DyDZ4/aaron-roberts-portfolio?type=design&node-id=2%3A36&mode=design&t=lML8ibo69XdkVg5Z-1