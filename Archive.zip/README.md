# portfolio

New design for my portfolio

figma files - https://www.figma.com/file/1gWylGSWgE5uZ2seYiDdyY/Aaron-Roberts-Porfolio?type=design&node-id=0%3A1&mode=design&t=ZVgXGWLGDNMRix5T-1